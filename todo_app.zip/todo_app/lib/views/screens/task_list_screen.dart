import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_app/providers/todo_provider.dart';
import 'package:todo_app/data/models/todo_model.dart';

class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  final TextEditingController _textFieldController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // This tells the app to download the tasks from the internet the very moment this screen opens
    Future.delayed(Duration.zero, () {
      Provider.of<TodoProvider>(context, listen: false).loadTodos();
    });
  }

  // A pop-up box that asks the user to type a new task name
  void _showAddTaskDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add New Task'),
          content: TextField(
            controller: _textFieldController,
            decoration: const InputDecoration(hintText: "Enter task title..."),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_textFieldController.text.trim().isNotEmpty) {
                  Provider.of<TodoProvider>(
                    context,
                    listen: false,
                  ).addTodo(_textFieldController.text.trim());
                  _textFieldController.clear();
                  Navigator.pop(context);
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // We "watch" the Provider. If anything changes in our provider, this entire build method reruns!
    final todoProvider = Provider.of<TodoProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Tasks (CRUD)'),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: _buildBody(todoProvider),
      // Floating button in the bottom right corner to add new tasks
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddTaskDialog(context),
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  // Helper widget to decide exactly what to display on the screen
  Widget _buildBody(TodoProvider provider) {
    // 1. LOADING STATE: If the app is downloading data, show a spinning circle
    if (provider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    // 2. ERROR STATE: If an error happened, display the text in red with a retry button
    if (provider.errorMessage.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 60),
              const SizedBox(height: 10),
              Text(
                provider.errorMessage,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => provider.loadTodos(),
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    // 3. EMPTY STATE: If no tasks exist
    if (provider.todos.isEmpty) {
      return const Center(child: Text('No tasks found. Add one!'));
    }

    // 4. DATA STATE: If data loaded successfully, show the scrollable list of items
    return ListView.builder(
      itemCount: provider.todos.length,
      itemBuilder: (context, index) {
        Todo todo = provider.todos[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(
            // UPDATE: Clicking the checkbox triggers our provider to toggle completion status
            leading: Checkbox(
              value: todo.completed,
              onChanged: (_) => provider.toggleTodoStatus(todo),
            ),
            title: Text(
              todo.title,
              style: TextStyle(
                decoration: todo.completed
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
                color: todo.completed ? Colors.grey : Colors.black,
              ),
            ),
            // DELETE: Clicking the trash can icon deletes the item
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () => provider.removeTodo(todo.id),
            ),
          ),
        );
      },
    );
  }
}
