import 'package:flutter/material.dart';
import 'package:todo_app/data/models/todo_model.dart';
import 'package:todo_app/data/services/api_service.dart';

class TodoProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  // We start with a completely EMPTY list now!
  List<Todo> _todos = [];
  bool _isLoading = false;
  String _errorMessage = '';

  List<Todo> get todos => _todos;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  Future<void> loadTodos() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      _todos = [];
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addTodo(String title) async {
    try {
      int temporaryId = DateTime.now().millisecondsSinceEpoch;

      await _apiService.createTodo(title);

      Todo newTodo = Todo(id: temporaryId, title: title, completed: false);

      _todos.insert(0, newTodo);
      notifyListeners();
    } catch (e) {
      _errorMessage = "Failed to communicate with API, but task added locally.";
      notifyListeners();
    }
  }

  Future<void> toggleTodoStatus(Todo todo) async {
    final index = _todos.indexWhere((t) => t.id == todo.id);
    if (index != -1) {
      _todos[index] = Todo(
        id: todo.id,
        title: todo.title,
        completed: !todo.completed,
      );
      notifyListeners();
    }

    try {
      await _apiService.updateTodo(todo);
    } catch (e) {}
  }

  Future<void> removeTodo(int id) async {
    _todos.removeWhere((t) => t.id == id);
    notifyListeners();

    try {
      await _apiService.deleteTodo(id);
    } catch (e) {}
  }
}
