class Todo {
  final int id;
  final String title;
  final bool completed;

  // This is the constructor. It creates a Todo object in our code.
  Todo({required this.id, required this.title, required this.completed});

  // This is a "Factory". It takes raw internet data (JSON) and turns it into a Dart Todo object.
  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      completed: json['completed'] ?? false,
    );
  }

  // This turns our Dart Todo back into internet data (JSON) when we want to send updates.
  Map<String, dynamic> toJson() {
    return {'id': id, 'title': title, 'completed': completed};
  }
}
