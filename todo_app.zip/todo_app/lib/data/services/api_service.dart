import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:todo_app/data/models/todo_model.dart';

class ApiService {
  // The website address where our data lives
  final String baseUrl = "https://jsonplaceholder.typicode.com/todos";

  // 1. READ: Get the list of tasks from the internet
  Future<List<Todo>> fetchTodos() async {
    try {
      // We add '?_limit=10' so the website only sends us 10 items instead of 200!
      final response = await http.get(Uri.parse('$baseUrl?_limit=10'));

      // Code 200 means "Success / OK"
      if (response.statusCode == 200) {
        List<dynamic> body = jsonDecode(response.body);

        // This loops through the internet text and converts it into a clean list of Dart Todo objects
        return body.map((dynamic item) => Todo.fromJson(item)).toList();
      } else {
        throw Exception(
          "Server returned an error code: ${response.statusCode}",
        );
      }
    } catch (e) {
      throw Exception(
        "Could not fetch tasks. Please check your internet connection.",
      );
    }
  }

  // 2. CREATE: Send a brand new task to the internet
  Future<Todo> createTodo(String title) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "title": title,
          "completed": false,
          "userId": 1, // The API requires a user ID link
        }),
      );

      // Code 201 means "Successfully Created"
      if (response.statusCode == 201) {
        return Todo.fromJson(jsonDecode(response.body));
      } else {
        throw Exception("Failed to add task on the server.");
      }
    } catch (e) {
      throw Exception("Error occurred while adding task.");
    }
  }

  // 3. UPDATE: Tell the internet that a task changed (like marking it completed)
  Future<void> updateTodo(Todo todo) async {
    try {
      // We add the specific task ID to the web address (e.g., .../todos/5)
      final response = await http.put(
        Uri.parse('$baseUrl/${todo.id}'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(todo.toJson()),
      );

      if (response.statusCode != 200) {
        throw Exception("Failed to update task on the server.");
      }
    } catch (e) {
      throw Exception("Error occurred while updating task.");
    }
  }

  // 4. DELETE: Tell the internet to erase a task
  Future<void> deleteTodo(int id) async {
    try {
      final response = await http.delete(Uri.parse('$baseUrl/$id'));

      if (response.statusCode != 200) {
        throw Exception("Failed to delete task on the server.");
      }
    } catch (e) {
      throw Exception("Error occurred while deleting task.");
    }
  }
}
